import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

void pushReplacment(String route, BuildContext context) {
  GoRouter.of(context).pushReplacement(route);
}

void pushTo(String route, BuildContext context) {
  GoRouter.of(context).push(route);
}

void pop(BuildContext context) {
  GoRouter.of(context).pop();
}

void pushAndClearStack(String route, BuildContext context) {
  GoRouter.of(context).go(route);
}
