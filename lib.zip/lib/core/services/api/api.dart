abstract class Apis {
  static const String baseUrl = "https://codingarabic.online/api/";

  //auth
  static const String register = "register";
  static const String login = "login";
  static const String forgetPassword = "forget-password";
  static const String resetPassword = "reset-password";
  static const String sliders = "sliders";
  static const String productsBestSeller = "products-bestseller";
  static const String wishlist = "wishlist";
  static const String addToWishlist = "add-to-wishlist";
  static const String removeFromWishlist = "remove-from-wishlist";
  static const String cart = "cart";
  static const String addToCart = "add-to-cart";
  static const String removeFromCart = "remove-from-cart";
  static const String updateCart = "update-cart";
}
