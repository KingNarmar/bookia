import 'package:bookia/core/styles/app_colors.dart';
import 'package:bookia/core/widgets/main_button.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class CartScreenBtttomNavBar extends StatelessWidget {
  const CartScreenBtttomNavBar({
    super.key,
    required this.onPressed,
    required this.totalPrice,
    required this.text,
  });
  final double totalPrice;
  final Function() onPressed;
  final String text;
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "Total:",
              style: TextStyle(
                fontFamily: "Nunito Sans",
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: AppColors.grayColor,
              ),
            ),
            Text(
              "\$ $totalPrice",
              style: TextStyle(
                fontFamily: "Nunito Sans",
                fontSize: 20,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
        Gap(19),
        MainButton(text: text, onPressed: onPressed),
      ],
    );
  }
}
