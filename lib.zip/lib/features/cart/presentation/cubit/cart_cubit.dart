import 'package:bookia/features/cart/data/models/cart_response/cart_item.dart';
import 'package:bookia/features/cart/data/repo/cart_repo.dart';
import 'package:bookia/features/cart/presentation/cubit/cart_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CartCubit extends Cubit<CartState> {
  CartCubit() : super(CartInitialState());

  List<CartItem?> cartItems = [];

  void getCartItems() async {
    emit(CartLoadingState());
    var data = await CartRepo.getCartItems();
    cartItems = data;
    emit(CartSuccessState());
  }

  void removeFromCart(int itemId) async {
    emit(CartLoadingState());
    await CartRepo.removeFromCart(itemId);
    cartItems.removeWhere((item) => item?.itemId == itemId);
    emit(CartSuccessState());
  }

  void addToCart(int productId) async {
    emit(CartLoadingState());
    var data = await CartRepo.addToCart(productId);
    cartItems = data;
    emit(CartSuccessState());
  }
}
