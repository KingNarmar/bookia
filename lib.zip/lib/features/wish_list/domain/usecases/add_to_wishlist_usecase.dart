import 'package:bookia/core/error/failure.dart';
import 'package:bookia/core/usecase/usecase.dart';
import 'package:bookia/features/wish_list/data/models/wish_list_response/wish_list_response.dart';
import 'package:bookia/features/wish_list/domain/repositories/wishlist_repository.dart';
import 'package:dartz/dartz.dart';

class AddToWishlistUseCase implements UseCase<WishListResponse, int> {
  final WishlistRepository repository;

  AddToWishlistUseCase(this.repository);

  @override
  Future<Either<Failure, WishListResponse>> call(int params) {
    return repository.addToWishlist(params);
  }
}
